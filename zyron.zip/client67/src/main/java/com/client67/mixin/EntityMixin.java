package com.client67.mixin;

import com.client67.module.Modules.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public class EntityMixin {
    @Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true)
    private void c67$look(double dx, double dy, CallbackInfo ci) {
        if ((Object) this != MinecraftClient.getInstance().player) return;
        if (Freecam.on) {
            Freecam.yaw += (float) dx * 0.15f;
            Freecam.pitch = MathHelper.clamp(Freecam.pitch + (float) dy * 0.15f, -90f, 90f);
            ci.cancel();
        } else if (FreeLook.on) {
            FreeLook.yaw += (float) dx * 0.15f;
            FreeLook.pitch = MathHelper.clamp(FreeLook.pitch + (float) dy * 0.15f, -90f, 90f);
            ci.cancel();
        }
    }
}
