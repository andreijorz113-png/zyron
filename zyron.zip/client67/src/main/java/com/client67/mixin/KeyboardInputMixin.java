package com.client67.mixin;

import com.client67.module.Modules.Freecam;
import net.minecraft.client.input.Input;
import net.minecraft.client.input.KeyboardInput;
import net.minecraft.util.PlayerInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(KeyboardInput.class)
public class KeyboardInputMixin {
    /** While freecam is on, the real player stands still. */
    @Inject(method = "tick", at = @At("TAIL"))
    private void c67$tick(CallbackInfo ci) {
        if (!Freecam.on) return;
        Input in = (Input) (Object) this;
        in.playerInput = PlayerInput.DEFAULT;
        in.movementForward = 0;
        in.movementSideways = 0;
    }
}
