package com.client67.mixin;

import com.client67.module.Modules.MusicHud;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.client.sound.SoundManager;
import net.minecraft.sound.SoundCategory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(SoundManager.class)
public class SoundManagerMixin {
    @Inject(method = "play(Lnet/minecraft/client/sound/SoundInstance;)V", at = @At("HEAD"))
    private void c67$play(SoundInstance s, CallbackInfo ci) {
        SoundCategory c = s.getCategory();
        if (c == SoundCategory.MUSIC || c == SoundCategory.RECORDS) MusicHud.onSound(s.getId().getPath());
    }
}
