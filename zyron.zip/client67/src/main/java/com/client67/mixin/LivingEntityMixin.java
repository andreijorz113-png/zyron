package com.client67.mixin;

import com.client67.module.Modules.SwingSpeed;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public class LivingEntityMixin {
    @Inject(method = "getHandSwingDuration", at = @At("HEAD"), cancellable = true)
    private void c67$swing(CallbackInfoReturnable<Integer> cir) {
        if ((Object) this instanceof ClientPlayerEntity && SwingSpeed.active()) cir.setReturnValue(SwingSpeed.duration);
    }
}
