package com.client67.module;

public enum Category {
    RENDER("RENDER"), WORLD("WORLD"), MISC("MISC"), CLIENT("CLIENT");
    public final String label;
    Category(String l) { label = l; }
}
