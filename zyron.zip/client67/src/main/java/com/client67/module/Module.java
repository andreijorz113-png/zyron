package com.client67.module;

import com.client67.hud.HudElement;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;

public abstract class Module {
    public final String name;
    public String desc;
    public final Category category;
    public boolean enabled;
    public HudElement hud; // optional, shown while module is enabled

    protected final MinecraftClient mc = MinecraftClient.getInstance();

    protected Module(String name, String desc, Category category) {
        this.name = name; this.desc = desc; this.category = category;
    }

    public void toggle() { setEnabled(!enabled); }
    public void setEnabled(boolean e) {
        if (e == enabled) return;
        enabled = e;
        if (e) onEnable(); else onDisable();
    }
    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {}
    public void onRender(WorldRenderContext ctx) {}
    /** Right click on the module card in the menu (used for cycling a setting). */
    public void onRightClick() {}
}
