package com.client67.module;

import com.client67.hud.HudElement;
import com.client67.util.Render;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.*;
import net.minecraft.block.entity.*;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

import java.time.OffsetDateTime;
import java.util.*;

/** All built-in modules. */
public class Modules {

    // ───────────────────────── helpers ─────────────────────────
    static final int RADIUS = 24;

    static List<Box> scanBlocks(java.util.function.Predicate<BlockState> test) {
        List<Box> out = new ArrayList<>();
        var mc = net.minecraft.client.MinecraftClient.getInstance();
        BlockPos o = mc.player.getBlockPos();
        BlockPos.Mutable p = new BlockPos.Mutable();
        int minY = Math.max(mc.world.getBottomY(), o.getY() - RADIUS);
        int maxY = Math.min(mc.world.getTopYInclusive(), o.getY() + RADIUS);
        for (int x = o.getX() - RADIUS; x <= o.getX() + RADIUS; x++)
            for (int z = o.getZ() - RADIUS; z <= o.getZ() + RADIUS; z++)
                for (int y = minY; y <= maxY; y++) {
                    p.set(x, y, z);
                    if (test.test(mc.world.getBlockState(p))) out.add(new Box(p));
                }
        return out;
    }

    static List<WorldChunk> loadedChunks(int radius) {
        List<WorldChunk> out = new ArrayList<>();
        var mc = net.minecraft.client.MinecraftClient.getInstance();
        ChunkPos c = mc.player.getChunkPos();
        for (int dx = -radius; dx <= radius; dx++)
            for (int dz = -radius; dz <= radius; dz++) {
                WorldChunk ch = mc.world.getChunkManager().getWorldChunk(c.x + dx, c.z + dz);
                if (ch != null) out.add(ch);
            }
        return out;
    }

    static boolean isStorage(BlockEntity be) {
        return be instanceof ChestBlockEntity || be instanceof BarrelBlockEntity || be instanceof ShulkerBoxBlockEntity
                || be instanceof EnderChestBlockEntity || be instanceof HopperBlockEntity || be instanceof DispenserBlockEntity
                || be instanceof FurnaceBlockEntity || be instanceof BlastFurnaceBlockEntity || be instanceof SmokerBlockEntity;
    }

    // ───────────────────────── RENDER ─────────────────────────
    public static class BlockEsp extends Module {
        static final Set<Block> TARGETS = Set.of(Blocks.DIAMOND_ORE, Blocks.DEEPSLATE_DIAMOND_ORE, Blocks.ANCIENT_DEBRIS,
                Blocks.EMERALD_ORE, Blocks.DEEPSLATE_EMERALD_ORE, Blocks.SPAWNER, Blocks.GOLD_ORE, Blocks.DEEPSLATE_GOLD_ORE);
        List<Box> boxes = List.of(); int t;
        public BlockEsp() { super("Block ESP", "Highlights ores, ancient debris and spawners", Category.RENDER); }
        @Override public void onTick() { if (t++ % 20 == 0) boxes = scanBlocks(s -> TARGETS.contains(s.getBlock())); }
        @Override public void onRender(WorldRenderContext c) { Render.boxes(c, boxes, 0.3f, 0.9f, 1f); }
    }

    public static class MobEsp extends Module {
        public MobEsp() { super("Mob ESP", "Boxes around mobs through walls", Category.RENDER); }
        @Override public void onRender(WorldRenderContext c) {
            List<Box> b = new ArrayList<>();
            for (var e : mc.world.getEntities())
                if (e instanceof LivingEntity && !(e instanceof PlayerEntity) && e != mc.player) b.add(e.getBoundingBox());
            Render.boxes(c, b, 1f, 0.3f, 0.3f);
        }
    }

    public static class StorageEsp extends Module {
        List<Box> boxes = List.of(); int t;
        public StorageEsp() { super("Storage ESP", "Chests, barrels, shulkers, hoppers, furnaces", Category.RENDER); }
        @Override public void onTick() {
            if (t++ % 20 != 0) return;
            List<Box> b = new ArrayList<>();
            for (WorldChunk ch : loadedChunks(6))
                for (BlockEntity be : ch.getBlockEntities().values()) if (isStorage(be)) b.add(new Box(be.getPos()));
            boxes = b;
        }
        @Override public void onRender(WorldRenderContext c) { Render.boxes(c, boxes, 1f, 0.65f, 0.1f); }
    }

    public static class SuspiciousEsp extends Module {
        List<Box> boxes = List.of(); int t;
        public SuspiciousEsp() { super("Suspicious ESP", "Suspicious sand/gravel (archaeology) + trial spawners", Category.RENDER); }
        @Override public void onTick() {
            if (t++ % 20 == 0) boxes = scanBlocks(s -> s.isOf(Blocks.SUSPICIOUS_SAND) || s.isOf(Blocks.SUSPICIOUS_GRAVEL)
                    || s.isOf(Blocks.TRIAL_SPAWNER) || s.isOf(Blocks.VAULT));
        }
        @Override public void onRender(WorldRenderContext c) { Render.boxes(c, boxes, 1f, 0.4f, 0.85f); }
    }

    public static class Fullbright extends Module {
        public Fullbright() { super("Fullbright", "Maximum brightness everywhere", Category.RENDER); }
        @Override public void onTick() {
            if (!mc.player.hasStatusEffect(StatusEffects.NIGHT_VISION))
                mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 32767, 0, false, false, false));
        }
        @Override public void onDisable() { if (mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION); }
    }

    public static class Freecam extends Module {
        public static boolean on; public static double x, y, z; public static float yaw, pitch;
        public Freecam() { super("Freecam", "Fly the camera without moving your player", Category.RENDER); }
        @Override public void onEnable() {
            if (mc.player == null) return;
            Vec3d p = mc.player.getEyePos(); x = p.x; y = p.y; z = p.z; yaw = mc.player.getYaw(); pitch = mc.player.getPitch(); on = true;
        }
        @Override public void onDisable() { on = false; }
        @Override public void onTick() {
            double speed = mc.options.sprintKey.isPressed() ? 1.2 : 0.5;
            double f = (mc.options.forwardKey.isPressed() ? 1 : 0) - (mc.options.backKey.isPressed() ? 1 : 0);
            double s = (mc.options.leftKey.isPressed() ? 1 : 0) - (mc.options.rightKey.isPressed() ? 1 : 0);
            double v = (mc.options.jumpKey.isPressed() ? 1 : 0) - (mc.options.sneakKey.isPressed() ? 1 : 0);
            double r = Math.toRadians(yaw);
            x += (-Math.sin(r) * f + Math.cos(r) * s) * speed;
            z += (Math.cos(r) * f + Math.sin(r) * s) * speed;
            y += v * speed;
        }
    }

    public static class FreeLook extends Module {
        public static boolean on; public static float yaw, pitch;
        public FreeLook() { super("Free Look", "Look around without turning your player", Category.RENDER); }
        @Override public void onEnable() { if (mc.player != null) { yaw = mc.player.getYaw(); pitch = mc.player.getPitch(); on = true; } }
        @Override public void onDisable() { on = false; }
    }

    public static class BlockEntityDebug extends Module {
        final Map<String, Integer> counts = new TreeMap<>(); int t;
        public BlockEntityDebug() {
            super("Block Entity Debug", "Counts loaded block entities by type", Category.RENDER);
            hud = new HudElement("Block Entities", 6, 60, () -> {
                List<String> l = new ArrayList<>();
                counts.entrySet().stream().sorted((a, b) -> b.getValue() - a.getValue()).limit(10)
                        .forEach(e -> l.add(e.getKey() + ": " + e.getValue()));
                if (l.isEmpty()) l.add("none loaded");
                return l;
            });
        }
        @Override public void onTick() {
            if (t++ % 20 != 0) return;
            counts.clear();
            for (WorldChunk ch : loadedChunks(8))
                for (BlockEntity be : ch.getBlockEntities().values()) {
                    String n = net.minecraft.registry.Registries.BLOCK_ENTITY_TYPE.getId(be.getType()).getPath();
                    counts.merge(n, 1, Integer::sum);
                }
        }
    }

    // ───────────────────────── WORLD (chunk finders) ─────────────────────────
    /** Shared scoring. Block entities are weighted; sections containing player-made blocks add to the score. */
    static abstract class ChunkFinder extends Module {
        static final Map<ChunkPos, int[]> SCORES = new HashMap<>(); // [manMadeSections, storageWeight]
        static int lastScan;
        List<Box> boxes = List.of();
        ChunkFinder(String n, String d) { super(n, d, Category.WORLD); }

        static boolean manMade(BlockState s) {
            Block b = s.getBlock();
            return b == Blocks.GLASS || b == Blocks.TORCH || b == Blocks.WALL_TORCH || b == Blocks.CRAFTING_TABLE
                    || b == Blocks.FURNACE || b instanceof BedBlock || b instanceof DoorBlock || b == Blocks.LADDER
                    || b == Blocks.OAK_PLANKS || b == Blocks.COBBLESTONE_STAIRS || b == Blocks.STONE_BRICKS || b == Blocks.GLOWSTONE;
        }

        static void scanAll(net.minecraft.client.MinecraftClient mc) {
            if (mc.player.age - lastScan < 40 && !SCORES.isEmpty()) return;
            lastScan = mc.player.age;
            SCORES.clear();
            for (WorldChunk ch : loadedChunks(8)) {
                int sections = 0, weight = 0;
                for (ChunkSection s : ch.getSectionArray()) if (s != null && !s.isEmpty() && s.hasAny(ChunkFinder::manMade)) sections++;
                for (BlockEntity be : ch.getBlockEntities().values()) {
                    if (be instanceof ShulkerBoxBlockEntity || be instanceof BedBlockEntity) weight += 3;
                    else if (be instanceof ChestBlockEntity || be instanceof BarrelBlockEntity) weight += 2;
                    else if (isStorage(be)) weight += 1;
                }
                SCORES.put(ch.getPos(), new int[]{sections, weight});
            }
        }

        abstract boolean matches(ChunkPos p, int[] s);

        @Override public void onTick() {
            scanAll(mc);
            double py = mc.player.getY();
            List<Box> b = new ArrayList<>();
            for (var e : SCORES.entrySet()) if (matches(e.getKey(), e.getValue()))
                b.add(new Box(e.getKey().getStartX(), py - 2, e.getKey().getStartZ(), e.getKey().getEndX() + 1, py + 14, e.getKey().getEndZ() + 1));
            boxes = b;
        }
        abstract float[] color();
        @Override public void onRender(WorldRenderContext c) { float[] k = color(); Render.boxes(c, boxes, k[0], k[1], k[2]); }
    }

    public static class SusChunkFinder extends ChunkFinder {
        public SusChunkFinder() { super("Sus Chunk Finder", "Chunks containing player-made blocks"); }
        @Override boolean matches(ChunkPos p, int[] s) { return s[0] >= 1 || s[1] >= 1; }
        @Override float[] color() { return new float[]{1f, 1f, 0.3f}; }
    }

    public static class BaseFinder extends ChunkFinder {
        public BaseFinder() { super("Base Finder", "Chunks with lots of storage / beds (likely bases)"); }
        @Override boolean matches(ChunkPos p, int[] s) { return s[1] >= 6; }
        @Override float[] color() { return new float[]{1f, 0.4f, 0.2f}; }
    }

    /** Assumption: "prime" = the single highest-scoring chunk nearby. Change matches() if you meant something else. */
    public static class PrimeChunkFinder extends ChunkFinder {
        public PrimeChunkFinder() { super("Prime Chunk Finder", "Highlights the single most built-up chunk nearby"); }
        @Override boolean matches(ChunkPos p, int[] s) {
            int mine = s[0] * 2 + s[1], best = 0;
            for (int[] o : SCORES.values()) best = Math.max(best, o[0] * 2 + o[1]);
            return best > 0 && mine == best;
        }
        @Override float[] color() { return new float[]{1f, 0.3f, 1f}; }
    }

    // ───────────────────────── MISC / CLIENT ─────────────────────────
    public static class SwingSpeed extends Module {
        public static int duration = 3;
        static final int[] OPTIONS = {1, 2, 3, 4, 6, 8, 12, 20};
        public SwingSpeed() { super("Swing Speed", "Arm swing duration: 3 ticks (right click to change)", Category.MISC); }
        @Override public void onRightClick() {
            int i = 0; for (int k = 0; k < OPTIONS.length; k++) if (OPTIONS[k] == duration) i = k;
            duration = OPTIONS[(i + 1) % OPTIONS.length];
            desc = "Arm swing duration: " + duration + " ticks (right click to change)";
        }
        public static boolean active() { SwingSpeed m = ModuleManager.get(SwingSpeed.class); return m != null && m.enabled; }
    }

    public static class MusicHud extends Module {
        public static volatile String track = "Nothing playing"; public static volatile long since;
        public MusicHud() {
            super("Music HUD", "Shows the current music / disc", Category.CLIENT);
            hud = new HudElement("Now Playing", 6, 6, () -> {
                String t = track.replace("minecraft:", "");
                int dot = t.lastIndexOf('.');
                if (t.startsWith("music.") || t.startsWith("music_disc.")) t = t.substring(t.indexOf('.') + 1);
                t = t.replace('_', ' ').replace('.', ' ');
                long s = (System.currentTimeMillis() - since) / 1000;
                return List.of(t, since == 0 ? "" : String.format("%d:%02d", s / 60, s % 60));
            });
        }
        public static void onSound(String path) { track = path; since = System.currentTimeMillis(); }
    }

    public static class DiscordPresence extends Module {
        /** Create an application at discord.com/developers and paste its Application ID here. */
        static final long APP_ID = 0L;
        private volatile com.client67.util.DiscordIpc ipc;
        private final long start = System.currentTimeMillis() / 1000;
        private int t;
        public DiscordPresence() { super("Discord Presence", "Rich presence (set APP_ID in code)", Category.CLIENT); }
        @Override public void onEnable() {
            if (APP_ID == 0L) { desc = "Set APP_ID in Modules.java first"; return; }
            Thread th = new Thread(() -> {
                var c = new com.client67.util.DiscordIpc();
                ipc = c.connect(APP_ID) ? c : null;
            }, "67-discord-connect");
            th.setDaemon(true);
            th.start();
        }
        @Override public void onDisable() { var c = ipc; ipc = null; if (c != null) c.close(); }
        @Override public void onTick() {
            var c = ipc;
            if (c == null || t++ % 200 != 0) return;
            String server = mc.getCurrentServerEntry() != null ? mc.getCurrentServerEntry().address : "Singleplayer";
            c.setActivity("Playing on " + server, "67 Client", start);
        }
    }
}
