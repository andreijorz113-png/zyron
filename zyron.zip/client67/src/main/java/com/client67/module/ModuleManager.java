package com.client67.module;

import com.client67.module.Modules.*;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    public static final List<Module> ALL = new ArrayList<>();

    public static void init() {
        ALL.add(new BlockEsp());
        ALL.add(new MobEsp());
        ALL.add(new StorageEsp());
        ALL.add(new SuspiciousEsp());
        ALL.add(new Fullbright());
        ALL.add(new Freecam());
        ALL.add(new FreeLook());
        ALL.add(new BlockEntityDebug());
        ALL.add(new SusChunkFinder());
        ALL.add(new BaseFinder());
        ALL.add(new PrimeChunkFinder());
        ALL.add(new SwingSpeed());
        ALL.add(new MusicHud());
        ALL.add(new DiscordPresence());
    }

    public static <T extends Module> T get(Class<T> c) {
        for (Module m : ALL) if (c.isInstance(m)) return c.cast(m);
        return null;
    }

    public static List<Module> in(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : ALL) if (m.category == c) out.add(m);
        return out;
    }

    public static void tick(MinecraftClient mc) {
        for (Module m : ALL) if (m.enabled) m.onTick();
    }

    public static void render(WorldRenderContext ctx) {
        for (Module m : ALL) if (m.enabled) m.onRender(ctx);
    }
}
