package com.client67.gui;

import com.client67.hud.HudElement;
import com.client67.hud.HudManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class HudEditorScreen extends Screen {
    private HudElement dragging;
    private int offX, offY;

    public HudEditorScreen() { super(Text.literal("HUD Editor")); }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        ctx.fillGradient(0, 0, width, height, 0xCC0C0912, 0xCC1A0F24);
        var list = HudManager.active();
        ctx.drawCenteredTextWithShadow(textRenderer, "HUD EDITOR - drag elements, ESC to go back", width / 2, 10, 0xFFFF7AC6);
        if (list.isEmpty())
            ctx.drawCenteredTextWithShadow(textRenderer, "Enable a HUD module (Music HUD / Block Entity Debug) first.", width / 2, height / 2, 0xFF8C8499);
        for (HudElement e : list) {
            e.render(ctx);
            ctx.drawBorder(e.x - 1, e.y - 1, e.w + 2, e.h + 2, e == dragging ? 0xFFFF7AC6 : 0x66FFFFFF);
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        for (HudElement e : HudManager.active())
            if (mx >= e.x && mx <= e.x + e.w && my >= e.y && my <= e.y + e.h) {
                dragging = e; offX = (int) mx - e.x; offY = (int) my - e.y; return true;
            }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging != null) {
            dragging.x = Math.max(0, Math.min(width - dragging.w, (int) mx - offX));
            dragging.y = Math.max(0, Math.min(height - dragging.h, (int) my - offY));
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) { dragging = null; return super.mouseReleased(mx, my, button); }

    @Override
    public void close() { client.setScreen(new MenuScreen()); }
}
