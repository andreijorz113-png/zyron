package com.client67.gui;

import com.client67.module.Category;
import com.client67.module.Module;
import com.client67.module.ModuleManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.List;

public class MenuScreen extends Screen {
    static final int PANEL = 0xF0120D1A, BAR = 0xFF17111F, CARD = 0xFF1C1527, CARD_ON = 0xFF2A1B35;
    static final int ACCENT = 0xFFFF7AC6, DIM = 0xFF8C8499, WHITE = 0xFFEDE6F5;
    // the logo: block "Z" drawn from gradient squares (col,row on a 5x5 grid)
    static final int[][] LOGO = {{0,0},{1,0},{2,0},{3,0},{4,0},{3,1},{2,2},{1,3},{0,4},{1,4},{2,4},{3,4},{4,4}};

    private Category selected = Category.RENDER;
    private int px, py;
    static final int PW = 480, PH = 300, SIDE = 112, TOP = 34;

    public MenuScreen() { super(Text.literal("67 Client")); }

    @Override
    protected void init() { px = (width - PW) / 2; py = (height - PH) / 2; }

    private void logo(DrawContext ctx, int x, int y, int s) {
        for (int[] c : LOGO)
            ctx.fillGradient(x + c[0] * (s + 1), y + c[1] * (s + 1), x + c[0] * (s + 1) + s, y + c[1] * (s + 1) + s, 0xFF5B8CFF, 0xFFFF4FD8);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        // background: deep purple/black glow
        ctx.fillGradient(0, 0, width, height, 0xFF07050C, 0xFF160B24);
        ctx.fillGradient(width / 2 - 160, height / 2 - 100, width / 2 + 160, height / 2 + 100, 0x00000000, 0x18B04CFF);

        ctx.fill(px, py, px + PW, py + PH, PANEL);
        ctx.drawBorder(px, py, PW, PH, 0xFF2A2036);
        ctx.fill(px, py, px + PW, py + TOP, BAR);

        // logo + tabs
        logo(ctx, px + 10, py + 8, 3);
        String[] tabs = {"MODULES", "HUD", "SETTINGS"};
        int tx = px + 48;
        for (int i = 0; i < tabs.length; i++) {
            int w = textRenderer.getWidth(tabs[i]) + 16;
            boolean on = i == 0, hov = mx >= tx && mx <= tx + w && my >= py + 7 && my <= py + 27;
            ctx.fill(tx, py + 7, tx + w, py + 27, on ? 0xFF2A1B35 : hov ? 0xFF221A2D : 0xFF1C1527);
            if (on) ctx.fill(tx, py + 26, tx + w, py + 27, ACCENT);
            ctx.drawText(textRenderer, tabs[i], tx + 8, py + 13, on ? WHITE : DIM, false);
            tx += w + 6;
        }
        ctx.drawText(textRenderer, "x", px + PW - 12, py + 13, DIM, false);

        // sidebar
        int sy = py + TOP + 10;
        for (Category c : Category.values()) {
            boolean on = c == selected;
            ctx.fill(px + 8, sy, px + SIDE, sy + 26, on ? 0xFF2A1B35 : CARD);
            if (on) ctx.fill(px + 8, sy, px + 10, sy + 26, ACCENT);
            ctx.drawText(textRenderer, c.label, px + 20, sy + 9, on ? ACCENT : WHITE, false);
            sy += 32;
        }

        // module cards (two columns)
        List<Module> mods = ModuleManager.in(selected);
        int cx0 = px + SIDE + 12, cw = (PW - SIDE - 12 - 12 - 8) / 2;
        for (int i = 0; i < mods.size(); i++) {
            Module m = mods.get(i);
            int x = cx0 + (i % 2) * (cw + 8), y = py + TOP + 10 + (i / 2) * 40;
            boolean hov = mx >= x && mx <= x + cw && my >= y && my <= y + 34;
            ctx.fill(x, y, x + cw, y + 34, m.enabled ? CARD_ON : hov ? 0xFF211A2D : CARD);
            if (m.enabled) ctx.fill(x, y, x + 2, y + 34, ACCENT);
            ctx.drawText(textRenderer, m.name.toUpperCase(), x + 8, y + 7, m.enabled ? ACCENT : WHITE, false);
            String d = textRenderer.trimToWidth(m.desc, cw - 60);
            ctx.drawText(textRenderer, d, x + 8, y + 19, DIM, false);
            // toggle
            int tgx = x + cw - 30, tgy = y + 12;
            ctx.fill(tgx, tgy, tgx + 22, tgy + 10, m.enabled ? ACCENT : 0xFF3A3345);
            int kx = m.enabled ? tgx + 12 : tgx;
            ctx.fill(kx, tgy, kx + 10, tgy + 10, 0xFFFFFFFF);
        }
        ctx.drawText(textRenderer, mods.size() + " MODULES  -  right click: module option  -  RSHIFT: menu",
                px + SIDE + 12, py + PH - 14, 0xFF5E566B, false);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        // tabs
        String[] tabs = {"MODULES", "HUD", "SETTINGS"};
        int tx = px + 48;
        for (int i = 0; i < tabs.length; i++) {
            int w = textRenderer.getWidth(tabs[i]) + 16;
            if (mx >= tx && mx <= tx + w && my >= py + 7 && my <= py + 27) {
                if (i == 1) client.setScreen(new HudEditorScreen());
                return true;
            }
            tx += w + 6;
        }
        if (mx >= px + PW - 18 && mx <= px + PW && my >= py && my <= py + TOP) { close(); return true; }

        int sy = py + TOP + 10;
        for (Category c : Category.values()) {
            if (mx >= px + 8 && mx <= px + SIDE && my >= sy && my <= sy + 26) { selected = c; return true; }
            sy += 32;
        }
        List<Module> mods = ModuleManager.in(selected);
        int cx0 = px + SIDE + 12, cw = (PW - SIDE - 12 - 12 - 8) / 2;
        for (int i = 0; i < mods.size(); i++) {
            int x = cx0 + (i % 2) * (cw + 8), y = py + TOP + 10 + (i / 2) * 40;
            if (mx >= x && mx <= x + cw && my >= y && my <= y + 34) {
                if (button == 0) mods.get(i).toggle(); else if (button == 1) mods.get(i).onRightClick();
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean shouldPause() { return false; }
}
