package com.client67.hud;

import com.client67.module.Module;
import com.client67.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

public class HudManager {
    public static List<HudElement> active() {
        List<HudElement> out = new ArrayList<>();
        for (Module m : ModuleManager.ALL) if (m.enabled && m.hud != null) out.add(m.hud);
        return out;
    }

    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden || mc.currentScreen != null) return;
        for (HudElement e : active()) e.render(ctx);
    }
}
