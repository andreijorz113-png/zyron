package com.client67.hud;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.List;
import java.util.function.Supplier;

public class HudElement {
    public final String name;
    public int x, y;
    public final Supplier<List<String>> lines;
    public int w = 80, h = 14;

    public HudElement(String name, int x, int y, Supplier<List<String>> lines) {
        this.name = name; this.x = x; this.y = y; this.lines = lines;
    }

    public void render(DrawContext ctx) {
        var tr = MinecraftClient.getInstance().textRenderer;
        List<String> ls = lines.get();
        int maxW = tr.getWidth(name);
        for (String s : ls) maxW = Math.max(maxW, tr.getWidth(s));
        w = maxW + 10;
        h = 14 + ls.size() * 10;
        ctx.fill(x, y, x + w, y + h, 0xB00C0912);
        ctx.fill(x, y, x + 2, y + h, 0xFFFF7AC6);
        ctx.drawText(tr, name, x + 6, y + 3, 0xFFFF7AC6, true);
        int yy = y + 14;
        for (String s : ls) { ctx.drawText(tr, s, x + 6, yy, 0xFFFFFFFF, true); yy += 10; }
    }
}
