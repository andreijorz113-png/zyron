package com.client67.util;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.List;

public class Render {
    /** Draws wireframe boxes through walls. */
    public static void boxes(WorldRenderContext ctx, List<Box> boxes, float r, float g, float b) {
        if (boxes.isEmpty()) return;
        MatrixStack m = ctx.matrixStack();
        if (m == null) return;
        Vec3d cam = ctx.camera().getPos();
        VertexConsumerProvider.Immediate imm = MinecraftClient.getInstance().getBufferBuilders().getEntityVertexConsumers();
        RenderSystem.disableDepthTest();
        m.push();
        m.translate(-cam.x, -cam.y, -cam.z);
        VertexConsumer vc = imm.getBuffer(RenderLayer.getLines());
        for (Box box : boxes) WorldRenderer.drawBox(m, vc, box, r, g, b, 1f);
        imm.draw(RenderLayer.getLines());
        m.pop();
        RenderSystem.enableDepthTest();
    }
}
