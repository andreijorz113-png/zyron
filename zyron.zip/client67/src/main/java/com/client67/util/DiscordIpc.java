package com.client67.util;

import java.io.*;
import java.net.UnixDomainSocketAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.Channels;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.UUID;

/** Minimal Discord Rich Presence client (talks to the local Discord app over its IPC pipe/socket). */
public class DiscordIpc {
    private Closeable conn;
    private InputStream in;
    private OutputStream out;
    private final boolean windows = System.getProperty("os.name").toLowerCase().contains("win");
    public volatile boolean ready;

    public boolean connect(long appId) {
        for (int i = 0; i < 10 && conn == null; i++) {
            try { open(i); } catch (Exception e) { conn = null; }
        }
        if (conn == null) return false;
        try {
            write(0, "{\"v\":1,\"client_id\":\"" + appId + "\"}");
            readFrame(); // READY
            ready = true;
            Thread t = new Thread(() -> {
                try { while (ready) readFrame(); } catch (Exception e) { ready = false; }
            }, "67-discord");
            t.setDaemon(true);
            t.start();
            return true;
        } catch (Exception e) {
            close();
            return false;
        }
    }

    private void open(int i) throws Exception {
        if (windows) {
            RandomAccessFile f = new RandomAccessFile("\\\\.\\pipe\\discord-ipc-" + i, "rw");
            conn = f; in = new FileInputStream(f.getFD()); out = new FileOutputStream(f.getFD());
        } else {
            String base = null;
            for (String k : new String[]{"XDG_RUNTIME_DIR", "TMPDIR", "TMP", "TEMP"}) {
                String v = System.getenv(k);
                if (v != null && !v.isEmpty()) { base = v; break; }
            }
            if (base == null) base = "/tmp";
            SocketChannel ch = SocketChannel.open(UnixDomainSocketAddress.of(Path.of(base, "discord-ipc-" + i)));
            conn = ch; in = Channels.newInputStream(ch); out = Channels.newOutputStream(ch);
        }
    }

    private synchronized void write(int op, String json) throws IOException {
        byte[] data = json.getBytes(StandardCharsets.UTF_8);
        ByteBuffer b = ByteBuffer.allocate(8 + data.length).order(ByteOrder.LITTLE_ENDIAN);
        b.putInt(op).putInt(data.length).put(data);
        out.write(b.array());
        out.flush();
    }

    private void waitAvailable(int n) throws Exception {
        if (!windows) return; // sockets block fine; Windows pipes must be polled
        long end = System.currentTimeMillis() + 60_000_000L;
        while (in.available() < n) {
            if (System.currentTimeMillis() > end) throw new IOException("timeout");
            Thread.sleep(100);
        }
    }

    private String readFrame() throws Exception {
        waitAvailable(8);
        byte[] h = in.readNBytes(8);
        if (h.length < 8) throw new IOException("closed");
        ByteBuffer hb = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN);
        hb.getInt();
        int len = hb.getInt();
        waitAvailable(len);
        return new String(in.readNBytes(len), StandardCharsets.UTF_8);
    }

    private static String esc(String s) { return s.replace("\\", "\\\\").replace("\"", "\\\""); }

    public void setActivity(String details, String state, long startEpochSeconds) {
        if (!ready) return;
        try {
            write(1, "{\"cmd\":\"SET_ACTIVITY\",\"args\":{\"pid\":" + ProcessHandle.current().pid()
                    + ",\"activity\":{\"details\":\"" + esc(details) + "\",\"state\":\"" + esc(state)
                    + "\",\"timestamps\":{\"start\":" + startEpochSeconds + "}}},\"nonce\":\"" + UUID.randomUUID() + "\"}");
        } catch (Exception e) { ready = false; }
    }

    public void close() {
        ready = false;
        try { if (conn != null) conn.close(); } catch (Exception ignored) {}
        conn = null;
    }
}
