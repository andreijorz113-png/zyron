# 67 Client (Fabric 1.21.4)

Build:  `gradle build`  (Gradle 8.10+, JDK 21)  ->  build/libs/client67-1.0.0.jar
Drop the jar + Fabric API into .minecraft/mods.  RIGHT SHIFT opens the menu.

Discord Presence: put your Application ID in `Modules.DiscordPresence.APP_ID`.
Right click a module card for its option (Swing Speed cycles duration).
